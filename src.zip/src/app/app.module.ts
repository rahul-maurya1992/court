import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { GetstartPage } from '../pages/getstart/getstart';
import { DirectoryPage } from '../pages/directory/directory';
import { Appsetting } from '../providers/appsetting';
import { HttpModule } from '@angular/http';
import { GoverningbodyPage } from '../pages/governingbody/governingbody';
import { IncumbencyPage } from '../pages/incumbency/incumbency';
import { GalleryPage } from '../pages/gallery/gallery';
import { JudgesPage } from '../pages/judges/judges';
import { RevenuePage } from '../pages/revenue/revenue';
import { ServicesPage } from '../pages/services/services';
import { ServicesdetailPage } from '../pages/servicesdetail/servicesdetail';
import { InAppBrowser } from '@ionic-native/in-app-browser';


@NgModule({
  declarations: [
    MyApp,
    HomePage,
    GetstartPage,
    DirectoryPage,
    GoverningbodyPage,
    IncumbencyPage,
    GalleryPage,
    RevenuePage,
    JudgesPage,
    ServicesPage,
    ServicesdetailPage

  ],
  imports: [
    BrowserModule,
    HttpModule,
    IonicModule.forRoot(MyApp),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    GetstartPage,
    DirectoryPage,
    GoverningbodyPage,
    IncumbencyPage,
    GalleryPage,
    RevenuePage,
    JudgesPage,
    ServicesPage,
    ServicesdetailPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    Appsetting,
    InAppBrowser,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {
}

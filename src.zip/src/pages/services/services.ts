import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import { Http,Response } from '@angular/http';
import { Appsetting } from '../../providers/appsetting';
import * as xml2js from 'xml2js';
import { GoverningbodyPage } from '../governingbody/governingbody';
import { ServicesdetailPage } from '../servicesdetail/servicesdetail';
import { InAppBrowser } from '@ionic-native/in-app-browser';
/**
 * Generated class for the ServicesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-services',
  templateUrl: 'services.html',
})
export class ServicesPage {
  gallerydata: any;
  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public http:Http,
    public appsetting:Appsetting,
    public loadingCtrl: LoadingController,
    private iab: InAppBrowser
  ) {
    
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ServicesPage');
  //  let options = this.appsetting.headers();
  //  var Loading = this.loadingCtrl.create({
  //   spinner: 'bubbles',
  //   content:'Loading'
  // });
  // Loading.present().then(() => {
  //   this.http.get(this.appsetting.myGlobalVar+'GetGalleryImages', options)
  //     .subscribe(data => {
  //       Loading.dismiss();
  //      // console.log(data['_body']);
  //       var jj = JSON.parse(data['_body']);
  //       console.log(JSON.parse(jj));
  //       this.gallerydata = JSON.parse(jj);
  //     })
  //   })
  }
  ServicesdetailPage(link){
    
  this.navCtrl.push(ServicesdetailPage,{url:link});
  // const browser = this.iab.create(link);
  // browser.close();
}

}

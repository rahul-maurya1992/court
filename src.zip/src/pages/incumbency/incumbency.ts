import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import { Http,Response } from '@angular/http';
import { Appsetting } from '../../providers/appsetting';
import * as xml2js from 'xml2js';
import { GoverningbodyPage } from '../governingbody/governingbody';

/**
 * Generated class for the DirectoryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-incumbency',
  templateUrl: 'incumbency.html',
})
export class IncumbencyPage {
  incumbencydata: any;
  url: string;
  ids: any;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public http:Http,
    public appsetting:Appsetting,
    public loadingCtrl: LoadingController
  ) {
  }

  ionViewDidLoad() {
    console.log(this.navParams.get('id'));
    this.ids = this.navParams.get('id');
    console.log('ionViewDidLoad IncumbencyPage');
   let options = this.appsetting.headers();
   var Loading = this.loadingCtrl.create({
    spinner: 'bubbles',
    content:'Loading'
  });
  Loading.present().then(() => {
    if(this.ids == 1){
      this.url = this.appsetting.myGlobalVar+'GetPresidentList';
    }else if(this.ids == 2){
      this.url = this.appsetting.myGlobalVar+'GetSecretaryData';
    }else if(this.ids ==3){
      this.url = this.appsetting.myGlobalVar+'GetVicePresidentList';
    }else if(this.ids ==4){
      this.url = this.appsetting.myGlobalVar+'GetJointSecretaryList';
    }else{
      this.url = null;
    }
    this.http.get(this.url, options).subscribe(data => {
        Loading.dismiss();
        var jj = JSON.parse(data['_body']);
        console.log(JSON.parse(jj));
        this.incumbencydata = JSON.parse(jj);
      })
    })
  }

GoverningbodyPage(){
  this.navCtrl.push(GoverningbodyPage);
}
}

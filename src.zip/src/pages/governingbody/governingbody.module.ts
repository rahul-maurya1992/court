import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { GoverningbodyPage } from './governingbody';

@NgModule({
  declarations: [
    GoverningbodyPage,
  ],
  imports: [
    IonicPageModule.forChild(GoverningbodyPage),
  ],
})
export class GoverningbodyPageModule {}

import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import { Http,Response } from '@angular/http';
import { Appsetting } from '../../providers/appsetting';
import * as xml2js from 'xml2js';
import { GoverningbodyPage } from '../governingbody/governingbody';
import { JudgesPage } from '../judges/judges';
import { RevenuePage } from '../revenue/revenue';
import { GalleryPage } from '../gallery/gallery';
import { ServicesPage } from '../services/services';

/**
 * Generated class for the DirectoryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-directory',
  templateUrl: 'directory.html',
})
export class DirectoryPage {
  directorydata: any;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public http:Http,
    public appsetting:Appsetting,
    public loadingCtrl: LoadingController
  ) {
    alert('directory vv ss');
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DirectoryPage');
   let options = this.appsetting.headers();
   var Loading = this.loadingCtrl.create({
    spinner: 'bubbles',
    content:'Loading...'
  });
  Loading.present().then(() => {
    
    this.http.get(this.appsetting.myGlobalVar+'GetDirectoryData', options)
      .subscribe(data => {
        Loading.dismiss();
       // console.log(data['_body']);
        var jj = JSON.parse(data['_body']);
        console.log(JSON.parse(jj));
        this.directorydata = JSON.parse(jj);
      })
    })
  }
GoverningbodyPage(){
  this.navCtrl.push(GoverningbodyPage);
}
judges(){
  this.navCtrl.push(JudgesPage);
}
revenue(){
  this.navCtrl.push(RevenuePage);
}
gallery(){
  this.navCtrl.push(GalleryPage);
}
services(){
  this.navCtrl.push(ServicesPage);
}
}

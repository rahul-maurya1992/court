import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ServicesdetailPage } from './servicesdetail';


@NgModule({
  declarations: [
    ServicesdetailPage,
  ],
  imports: [
    IonicPageModule.forChild(ServicesdetailPage),
  ],
})
export class ServicesdetailPageModule {}
